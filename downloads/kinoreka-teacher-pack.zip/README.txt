КИНОРЕКА — онлайн-кинотеатр · KINOREKA — streaming
================================================================

ПАКЕТ ПРЕПОДАВАТЕЛЯ · TEACHER PACK

Что внутри / What is inside:
  kinoreka-streaming-simulator-v1.29.5.html
      — сама игра одним файлом: двойной щелчок, интернет не нужен.
        The game as a single file: double-click it, no internet needed.
  docs/teacher-guide.html (RU) · docs/en/teacher-guide.html (EN)
      — сценарии занятий с хронометражем.
        Lesson plans with timings.
  docs/economics.html (RU) · docs/en/economics.html (EN)
      — разбор всех формул модели.
        The full formula write-up.
  results.csv
      — шаблон таблицы для сбора работ.
        A template for collecting results.

Первые пять минут занятия / The first five minutes:
  1. Придумайте код партии (например, "урок-7б") и продиктуйте группе.
     Invent a game code (say, "class-7b") and dictate it to the group.
  2. Каждый вводит код на экране приветствия — у всех один город.
     Everyone enters it on the welcome screen — same city for all.
  3. В конце соберите строки результата: контрольная сумма не даст
     подделать счёт. Кнопка «Скопировать» — на финальном экране.
     Collect the result strings at the end: the checksum makes score
     doctoring harder than honest play. The Copy button is on the
     final screen.

Онлайн-версия и язык в ссылке / Online version and language links:
  https://ruben-deev.github.io/economics-simulators/games/cinema/?lang=ru
  https://ruben-deev.github.io/economics-simulators/games/cinema/?lang=en

Лицензия / Licence: CC BY-NC-SA 4.0 · Ruben Deev
